package com.cognizant.beans;

// Infrastructure services e.g Security,Tracing,Debugging,Performance Monitoring
//Persistence,Database operations etc

//Spring Bean is infrastructure service class which provides above mentioned infrastructure services.

//Spring Bean Object life cycle are managed by IOC Container(Loosely coupled container)

//Information (configuration) required to manage life cycle of 
//Spring bean must be provided either using XML or annotations

public class Bean1 {
	
	public Bean1(){}
	
	//Method provides some infrastructure services
	public void x(){
		System.out.println("--x called--");
	}

}
