package com.cognizant.beans;

public class Bean2 {
	public Bean2(){
		System.out.println("--Bean2 constructor--");
	}

}
