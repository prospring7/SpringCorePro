package com.cognizant.beans;

public class Bean3 {
	
	public Bean3(){
		System.out.println("--Bean3 constructor--");
	}

}
