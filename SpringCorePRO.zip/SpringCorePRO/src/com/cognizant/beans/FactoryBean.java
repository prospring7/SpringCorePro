package com.cognizant.beans;

public class FactoryBean {
	
	//Factory Method
	public Bean5 createInstanceBean5(){
		System.out.println("--createInstanceBean5--");
		Bean5 bean5=new Bean5();
		return bean5;
	}

}
