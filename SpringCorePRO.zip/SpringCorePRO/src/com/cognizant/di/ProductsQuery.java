package com.cognizant.di;

public class ProductsQuery {
	
	private String selectProducts;
	private String insertProduct;
	
	public ProductsQuery(){}

	public String getSelectProducts() {
		return selectProducts;
	}

	public void setSelectProducts(String selectProducts) {
		this.selectProducts = selectProducts;
	}

	public String getInsertProduct() {
		return insertProduct;
	}

	public void setInsertProduct(String insertProduct) {
		this.insertProduct = insertProduct;
	}
	
	

}
